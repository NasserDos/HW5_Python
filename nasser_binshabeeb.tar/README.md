No opts
	
main()
	calls get_input()

get_input()
	prompts for user input and checks the input if it matches 1234



